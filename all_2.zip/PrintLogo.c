#include "System.h"


void printLogo() {
	system("cls");
	printf("XXXXXXX X     X  XXXX   X  XX     X   XXXXX  \n");
	printf("   X     X   X   X   X  X  X X    X  X     X \n");
	printf("   X      XXX    X   X  X  X  X   X  X       \n");
	printf("   X       X     XXXX   X  X   X  X  X  XXXX \n");
	printf("   X       X     X      X  X    X X  X    X  \n");
	printf("   X       X     X      X  X     XX   XXXXX  \n");
	printf("\n\n");
}